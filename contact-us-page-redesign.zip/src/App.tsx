import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Phone, 
  Mail, 
  Clock, 
  MapPin, 
  Send, 
  MessageSquare, 
  Globe, 
  ChevronRight,
  Headphones,
  CheckCircle2,
  Menu,
  X
} from 'lucide-react';

// --- Components ---

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 w-full z-50 bg-slate-950/80 backdrop-blur-xl border-b border-white/5">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-2xl font-black tracking-tighter text-white"
        >
          ARASB<span className="text-amber-500 underline decoration-2 underline-offset-4">TRADING</span>
        </motion.div>
        
        <div className="hidden md:flex items-center space-x-10 text-sm font-bold uppercase tracking-widest text-white/70">
          <a href="#" className="hover:text-amber-500 transition-colors">Home</a>
          <a href="#" className="hover:text-amber-500 transition-colors">Services</a>
          <a href="#" className="hover:text-amber-500 transition-colors">About</a>
          <a href="#" className="text-amber-500">Contact</a>
        </div>

        <div className="flex items-center gap-4">
          <button className="hidden sm:block px-6 py-2.5 bg-white text-black rounded-full text-xs font-black uppercase tracking-widest hover:bg-amber-500 hover:text-white transition-all">
            Get Started
          </button>
          <button className="md:hidden text-white" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-slate-900 border-b border-white/5 px-6 py-8 space-y-4"
          >
            {['Home', 'Services', 'About', 'Contact'].map((item) => (
              <a key={item} href="#" className="block text-xl font-bold text-white hover:text-amber-500">{item}</a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const ContactInfoCard = ({ icon: Icon, title, content, subContent, delay }: any) => (
  <motion.div
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    transition={{ delay, duration: 0.5 }}
    viewport={{ once: true }}
    className="group p-8 rounded-[2rem] bg-slate-900/40 border border-white/5 backdrop-blur-3xl hover:border-amber-500/30 transition-all duration-500"
  >
    <div className="w-14 h-14 rounded-2xl bg-amber-500/10 flex items-center justify-center mb-8 group-hover:scale-110 group-hover:bg-amber-500/20 transition-all duration-500">
      <Icon className="w-7 h-7 text-amber-500" />
    </div>
    <h3 className="text-xl font-bold text-white mb-3 tracking-tight">{title}</h3>
    <div className="space-y-1">
      <p className="text-slate-300 font-medium">{content}</p>
      {subContent && <p className="text-slate-500 text-sm leading-relaxed">{subContent}</p>}
    </div>
  </motion.div>
);

const FormInput = ({ label, type = "text", placeholder, name }: any) => (
  <div className="space-y-3">
    <label className="text-xs font-black uppercase tracking-widest text-slate-400 ml-1">{label}</label>
    <input 
      type={type}
      name={name}
      placeholder={placeholder}
      className="w-full px-6 py-5 rounded-2xl bg-white/5 border border-white/5 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500/50 transition-all font-medium"
    />
  </div>
);

const App = () => {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 5000);
  };

  return (
    <div className="min-h-screen bg-[#020408] text-slate-300 font-sans selection:bg-amber-500/30 selection:text-amber-500">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-44 pb-32 overflow-hidden">
        {/* Abstract Background Elements */}
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-amber-600/5 blur-[150px] rounded-full -mr-96 -mt-96 animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-blue-600/5 blur-[150px] rounded-full -ml-48 -mb-48"></div>

        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="flex flex-col items-center text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 mb-8 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm"
            >
              <div className="w-2 h-2 rounded-full bg-amber-500 animate-ping"></div>
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-amber-500">Available Globally 24/7</span>
            </motion.div>
            
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
              className="text-6xl md:text-8xl font-black text-white mb-10 tracking-tighter leading-[0.9]"
            >
              LET'S TALK <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-600 to-amber-700">BUSINESS.</span>
            </motion.h1>
            
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="text-lg md:text-xl text-slate-400 max-w-2xl leading-relaxed font-medium"
            >
              Arasb Trading bridges the gap between markets. Reach out today and let's explore how we can optimize your supply chain.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="pb-40 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-12 gap-20">
            
            {/* Contact Info Side */}
            <div className="lg:col-span-5 space-y-12">
              <div className="space-y-6">
                <h2 className="text-4xl font-black text-white tracking-tight">GET IN TOUCH</h2>
                <div className="h-1.5 w-20 bg-amber-500 rounded-full"></div>
                <p className="text-slate-400 text-lg leading-relaxed">
                  Connect with our team of experts across our global administrative hubs.
                </p>
              </div>

              <div className="grid gap-6">
                <ContactInfoCard 
                  icon={Phone} 
                  title="Direct Contact" 
                  content="+98 913 3777 118" 
                  subContent="Available for urgent commercial inquiries."
                  delay={0.1}
                />
                <ContactInfoCard 
                  icon={MessageSquare} 
                  title="WhatsApp Support" 
                  content="🇦🇪 +971 504 369 740" 
                  subContent="🇮🇷 +98 913 3777 118"
                  delay={0.2}
                />
                <ContactInfoCard 
                  icon={Mail} 
                  title="Official Email" 
                  content="info@Arasbtrading.com" 
                  subContent="Response guaranteed within 24 business hours."
                  delay={0.3}
                />
                <ContactInfoCard 
                  icon={Clock} 
                  title="Office Hours" 
                  content="Mon–Fri 10AM-6PM / Sat 12PM-8PM" 
                  subContent="Time zones: GST (Dubai) / IRST (Tehran)"
                  delay={0.4}
                />
              </div>
            </div>

            {/* Form Side */}
            <div className="lg:col-span-7">
              <motion.div 
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="relative p-10 md:p-16 rounded-[3rem] bg-white/[0.02] border border-white/5 overflow-hidden shadow-[0_0_80px_rgba(0,0,0,0.5)]"
              >
                {/* Visual Accent */}
                <div className="absolute top-0 right-0 w-full h-2 bg-gradient-to-r from-transparent via-amber-500 to-transparent opacity-50"></div>

                <AnimatePresence mode="wait">
                  {!isSubmitted ? (
                    <motion.form 
                      key="form"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0, y: -20 }}
                      onSubmit={handleSubmit}
                      className="relative z-10 space-y-8"
                    >
                      <div className="grid md:grid-cols-2 gap-8">
                        <FormInput label="Full Name" placeholder="Your Name" />
                        <FormInput label="Email Address" type="email" placeholder="email@company.com" />
                      </div>
                      <div className="grid md:grid-cols-2 gap-8">
                        <FormInput label="Phone Number" placeholder="+971 ..." />
                        <div className="space-y-3">
                          <label className="text-xs font-black uppercase tracking-widest text-slate-400 ml-1">Service Type</label>
                          <select className="w-full px-6 py-5 rounded-2xl bg-white/5 border border-white/5 text-white focus:outline-none focus:ring-2 focus:ring-amber-500/50 appearance-none font-medium cursor-pointer">
                            <option className="bg-slate-950">Export Services</option>
                            <option className="bg-slate-950">Import Solutions</option>
                            <option className="bg-slate-950">Customs Brokerage</option>
                            <option className="bg-slate-950">Warehousing</option>
                          </select>
                        </div>
                      </div>
                      <FormInput label="Business Location" placeholder="Country" />
                      <div className="space-y-3">
                        <label className="text-xs font-black uppercase tracking-widest text-slate-400 ml-1">Message Detail</label>
                        <textarea 
                          rows={4} 
                          placeholder="Tell us about your project requirements..."
                          className="w-full px-6 py-5 rounded-2xl bg-white/5 border border-white/5 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500/50 transition-all resize-none font-medium"
                        ></textarea>
                      </div>
                      <button 
                        type="submit"
                        className="w-full py-6 rounded-2xl bg-gradient-to-r from-amber-600 to-amber-700 text-white font-black text-xs uppercase tracking-[0.3em] hover:from-amber-500 hover:to-amber-600 transition-all transform hover:scale-[1.01] active:scale-[0.99] flex items-center justify-center space-x-3 shadow-2xl shadow-amber-900/40"
                      >
                        <span>Initiate Contact</span>
                        <Send size={18} />
                      </button>
                    </motion.form>
                  ) : (
                    <motion.div 
                      key="success"
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="relative z-10 h-[500px] flex flex-col items-center justify-center text-center"
                    >
                      <div className="w-24 h-24 bg-amber-500/10 rounded-full flex items-center justify-center mb-8 border border-amber-500/20">
                        <CheckCircle2 size={48} className="text-amber-500" />
                      </div>
                      <h2 className="text-4xl font-black text-white mb-6 tracking-tight">MESSAGE RECEIVED</h2>
                      <p className="text-slate-400 max-w-sm leading-relaxed font-medium">
                        Your inquiry has been successfully transmitted to our commercial department. We will contact you shortly.
                      </p>
                      <button 
                        onClick={() => setIsSubmitted(false)}
                        className="mt-12 text-amber-500 font-black text-xs uppercase tracking-widest flex items-center gap-2 hover:gap-4 transition-all"
                      >
                        NEW SUBMISSION <ChevronRight size={16} />
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            </div>

          </div>
        </div>
      </section>

      {/* Global Presence Banner */}
      <section className="py-24 bg-white/5 border-y border-white/5 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 flex items-center justify-center pointer-events-none">
           <Globe size={600} strokeWidth={0.5} className="text-white animate-spin-slow" />
        </div>
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid md:grid-cols-3 gap-12 items-center">
            <div className="md:col-span-1">
              <h3 className="text-3xl font-black text-white mb-4 italic">GLOBAL SCALE.</h3>
              <p className="text-slate-400 font-medium leading-relaxed">
                Operating with precision across continents to ensure your trade never stops.
              </p>
            </div>
            <div className="md:col-span-2 flex flex-wrap gap-8 justify-end">
              {[
                { city: 'DUBAI', flag: '🇦🇪', zone: 'Middle East Hub' },
                { city: 'ISFAHAN', flag: '🇮🇷', zone: 'Central Logistics' },
                { city: 'SHANGHAI', flag: '🇨🇳', zone: 'Sourcing Hub' }
              ].map((loc, i) => (
                <div key={i} className="flex items-center gap-6 p-6 bg-slate-950/50 rounded-3xl border border-white/5 hover:border-amber-500/30 transition-colors">
                  <span className="text-4xl">{loc.flag}</span>
                  <div>
                    <h4 className="text-white font-black text-sm tracking-widest">{loc.city}</h4>
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tighter">{loc.zone}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-12">
            <div className="flex flex-col items-center md:items-start gap-4">
              <div className="text-3xl font-black tracking-tighter text-white">
                ARASB<span className="text-amber-500 underline decoration-2 underline-offset-8">TRADING</span>
              </div>
              <p className="text-slate-600 text-xs font-bold tracking-widest uppercase">
                Redefining International Commerce since 2010
              </p>
            </div>
            
            <div className="flex items-center space-x-12">
              <a href="#" className="text-white/40 hover:text-amber-500 transition-colors">
                <Globe size={20} />
              </a>
              <a href="#" className="text-white/40 hover:text-amber-500 transition-colors">
                <MessageSquare size={20} />
              </a>
              <a href="#" className="text-white/40 hover:text-amber-500 transition-colors">
                <Mail size={20} />
              </a>
            </div>

            <div className="text-slate-600 text-[10px] font-black uppercase tracking-[0.3em]">
              © 2024 ARASB TRADING GROUP.
            </div>
          </div>
        </div>
      </footer>

      {/* Support Float */}
      <motion.button 
        whileHover={{ scale: 1.05, rotate: 5 }}
        whileTap={{ scale: 0.95 }}
        className="fixed bottom-10 right-10 w-20 h-20 bg-amber-500 rounded-[2rem] flex items-center justify-center shadow-[0_20px_50px_rgba(245,158,11,0.3)] z-50 text-black border-4 border-black group overflow-hidden"
      >
        <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity"></div>
        <Headphones size={32} strokeWidth={2.5} />
      </motion.button>

      <style>{`
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 60s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default App;
