import { motion } from 'framer-motion';
import { 
  Search, 
  ClipboardCheck, 
  Truck, 
  ArrowUpRight, 
  ArrowDownLeft, 
  MessageSquare, 
  FileCheck, 
  Zap, 
  ShieldCheck,
  ArrowRight
} from 'lucide-react';

const services = [
  {
    title: "Vetted Sourcing",
    description: "Find vetted suppliers, matched to your specific industry requirements and quality standards.",
    icon: Search,
    color: "bg-amber-500"
  },
  {
    title: "QC Inspections",
    description: "Thorough inspections with clear, documented reports to ensure your peace of mind.",
    icon: ClipboardCheck,
    color: "bg-blue-500"
  },
  {
    title: "Reliable Shipping",
    description: "Seamless door-to-door coordination with real-time tracking and logistics optimization.",
    icon: Truck,
    color: "bg-emerald-500"
  },
  {
    title: "Export Handling",
    description: "Complete export management with full documentation support and regulatory compliance.",
    icon: ArrowUpRight,
    color: "bg-purple-500"
  },
  {
    title: "Import Coordination",
    description: "Smooth import processes with accurate documentation and risk mitigation strategies.",
    icon: ArrowDownLeft,
    color: "bg-rose-500"
  },
  {
    title: "Trade Consulting",
    description: "Strategic advice to reduce risks, optimize costs, and navigate complex international markets.",
    icon: MessageSquare,
    color: "bg-sky-500"
  },
  {
    title: "Licenses & Permits",
    description: "Efficiency in obtaining necessary trade licenses and permits through expert handling.",
    icon: FileCheck,
    color: "bg-indigo-500"
  },
  {
    title: "Fast Clearance",
    description: "Accelerated customs clearance through precise paperwork and local expertise.",
    icon: Zap,
    color: "bg-orange-500"
  },
  {
    title: "Customs Support",
    description: "Professional support for classification, documentation, and regulatory compliance.",
    icon: ShieldCheck,
    color: "bg-cyan-500"
  }
];

const Services = () => {
  return (
    <section id="services" className="py-24 bg-slate-900 relative overflow-hidden">
      {/* Decorative Grid Background */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
           style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '40px 40px' }} />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-amber-500 font-bold tracking-widest uppercase text-sm mb-4"
          >
            Our Expertise
          </motion.h2>
          <motion.h3 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-bold text-white mb-6"
          >
            End-to-End Trading Solutions
          </motion.h3>
          <motion.div 
            initial={{ width: 0 }}
            whileInView={{ width: 80 }}
            viewport={{ once: true }}
            className="h-1.5 bg-amber-500 mx-auto rounded-full"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="group bg-slate-800/50 border border-white/5 p-8 rounded-3xl hover:bg-slate-800 transition-all hover:border-amber-500/50"
            >
              <div className={`w-14 h-14 ${service.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-6 transition-transform shadow-lg`}>
                <service.icon className="w-7 h-7 text-slate-950" />
              </div>
              <h4 className="text-xl font-bold text-white mb-4 group-hover:text-amber-500 transition-colors">
                {service.title}
              </h4>
              <p className="text-slate-400 leading-relaxed mb-6">
                {service.description}
              </p>
              <div className="flex items-center gap-2 text-amber-500 font-semibold text-sm cursor-pointer group/link">
                Learn More 
                <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
