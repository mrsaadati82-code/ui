import { motion } from 'framer-motion';
import { Globe, Users, Award, Shield } from 'lucide-react';

const AboutDetail = () => {
  const stats = [
    { label: 'Founded', value: '1998', icon: Globe },
    { label: 'Team Experts', value: '250+', icon: Users },
    { label: 'Awards Won', value: '15+', icon: Award },
    { label: 'Secure Trades', value: '10K+', icon: Shield },
  ];

  return (
    <section id="about" className="py-24 bg-slate-950 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-20 items-center">
          <div className="relative">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative z-10 rounded-[2rem] overflow-hidden aspect-[4/5]"
            >
              <img 
                src="https://images.unsplash.com/photo-1554469384-e58fac16e23a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                alt="Architecture" 
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000"
              />
              <div className="absolute inset-0 bg-amber-500/10 mix-blend-overlay" />
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="absolute -bottom-10 -right-10 w-2/3 bg-amber-500 p-8 rounded-[2rem] shadow-2xl z-20"
            >
              <p className="text-slate-950 text-xl font-bold leading-tight">
                "We don't just ship goods; we deliver the future of your business."
              </p>
              <div className="mt-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-950/20" />
                <div>
                  <div className="text-sm font-black text-slate-950 uppercase">CEO, Arasb Trading</div>
                </div>
              </div>
            </motion.div>

            {/* Background elements */}
            <div className="absolute -top-10 -left-10 w-40 h-40 bg-blue-500/20 rounded-full blur-3xl animate-pulse" />
          </div>

          <div>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-amber-500 font-bold uppercase tracking-widest text-sm mb-4"
            >
              Our Legacy
            </motion.h2>
            <motion.h3
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-4xl md:text-5xl font-bold text-white mb-8 leading-tight"
            >
              Bridging Continents <br />
              Since 1998.
            </motion.h3>
            
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="text-slate-400 text-lg mb-10 leading-relaxed"
            >
              Arasb Trading began with a simple mission: to make international trade accessible, transparent, and efficient for businesses of all sizes. Today, we stand as a beacon of reliability in the global supply chain, serving clients across six continents.
            </motion.p>

            <div className="grid grid-cols-2 gap-8">
              {stats.map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="flex flex-col gap-2"
                >
                  <div className="flex items-center gap-2 text-amber-500">
                    <stat.icon className="w-5 h-5" />
                    <span className="text-3xl font-black text-white">{stat.value}</span>
                  </div>
                  <span className="text-slate-500 text-sm font-medium uppercase tracking-widest">{stat.label}</span>
                </motion.div>
              ))}
            </div>

            <motion.button
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5 }}
              className="mt-12 group flex items-center gap-2 text-white border-b-2 border-amber-500 pb-2 font-bold hover:text-amber-500 transition-colors"
            >
              Our Full Corporate Profile
              <Globe className="w-4 h-4 group-hover:rotate-12 transition-transform" />
            </motion.button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutDetail;
