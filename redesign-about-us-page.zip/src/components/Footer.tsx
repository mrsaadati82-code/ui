import { Globe2, Mail, Phone, MapPin, ArrowRight, Globe, MessageSquare, Share } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-slate-950 pt-24 pb-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="flex flex-col gap-6">
            <div className="flex items-center gap-2">
              <div className="bg-amber-500 p-2 rounded-lg">
                <Globe2 className="w-5 h-5 text-slate-950" />
              </div>
              <span className="text-xl font-bold tracking-tighter text-white uppercase italic">
                Arasb<span className="text-amber-500">Trading</span>
              </span>
            </div>
            <p className="text-slate-500 leading-relaxed">
              Global supply chain solutions tailored for the modern enterprise. We bridge the gap between markets with precision and trust.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center text-slate-400 hover:text-amber-500 hover:bg-slate-800 transition-all">
                <Globe className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center text-slate-400 hover:text-amber-500 hover:bg-slate-800 transition-all">
                <MessageSquare className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center text-slate-400 hover:text-amber-500 hover:bg-slate-800 transition-all">
                <Share className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-widest text-sm">Services</h4>
            <ul className="flex flex-col gap-4">
              {['Sourcing', 'Logistics', 'Customs', 'Quality Control', 'Consulting'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-slate-500 hover:text-amber-500 transition-colors flex items-center gap-2 group">
                    <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 -ml-5 group-hover:ml-0 transition-all" />
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-widest text-sm">Company</h4>
            <ul className="flex flex-col gap-4">
              {['About Us', 'Global Network', 'Careers', 'Privacy Policy', 'Terms of Service'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-slate-500 hover:text-amber-500 transition-colors flex items-center gap-2 group">
                    <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 -ml-5 group-hover:ml-0 transition-all" />
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-widest text-sm">Contact Us</h4>
            <ul className="flex flex-col gap-6">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-amber-500 shrink-0" />
                <span className="text-slate-500">
                  Unit 12, Arasb Building, <br />
                  Jordan St, Tehran, Iran
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-amber-500 shrink-0" />
                <span className="text-slate-500">+98 21 8888 4444</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-amber-500 shrink-0" />
                <span className="text-slate-500">info@arasbtrading.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-slate-600 text-sm">
            © 2024 Arasb Trading Company. All rights reserved.
          </p>
          <p className="text-slate-600 text-sm italic">
            Engineered for global excellence.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
