import { motion } from 'framer-motion';

const CTA = () => {
  return (
    <section className="py-24 px-6 bg-slate-950">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        className="max-w-7xl mx-auto bg-gradient-to-r from-amber-500 to-amber-600 rounded-[3rem] p-12 md:p-24 text-center relative overflow-hidden"
      >
        {/* Decorative Circles */}
        <div className="absolute top-0 left-0 w-64 h-64 bg-white/10 rounded-full -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-black/10 rounded-full translate-x-1/3 translate-y-1/3" />

        <div className="relative z-10 max-w-3xl mx-auto">
          <h2 className="text-4xl md:text-6xl font-black text-slate-950 mb-8 leading-tight">
            Ready to Scale Your Global Trade?
          </h2>
          <p className="text-slate-950/80 text-xl font-medium mb-12">
            Join hundreds of industry leaders who trust Arasb Trading for their end-to-end supply chain needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-slate-950 text-white px-10 py-5 rounded-full font-bold text-lg hover:bg-slate-900 transition-all shadow-2xl">
              Schedule a Consultation
            </button>
            <button className="bg-white/20 backdrop-blur-md text-slate-950 px-10 py-5 rounded-full font-bold text-lg hover:bg-white/30 transition-all">
              Contact Support
            </button>
          </div>
        </div>
      </motion.div>
    </section>
  );
};

export default CTA;
