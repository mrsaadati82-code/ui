import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import AboutDetail from './components/AboutDetail';
import CTA from './components/CTA';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 selection:bg-amber-500 selection:text-slate-950">
      <Navbar />
      <main>
        <Hero />
        <AboutDetail />
        <Services />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}

export default App;
